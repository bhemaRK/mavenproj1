package ActionsClass;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class KeysClass {

	public static void main(String[] args) {
		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// Implicitly wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the application url
		driver.get("https://www.facebook.com/");

		// maximize the screen
		driver.manage().window().maximize(); // method chaining

		// capture the email WebElement
		WebElement email = driver.findElement(By.id("email"));

		// capture the password WebElement
		WebElement password = driver.findElement(By.name("pass"));

		// enter email id in the email box
		email.sendKeys("rakeshsinghraks@gmail.com");
		
		// Create an object of Actions class
		Actions act = new Actions(driver);
		
		//Move to the email WebElement, click, press CONTROL button and send press CONTROL A
		act.moveToElement(email).click().keyDown(Keys.CONTROL).sendKeys("A", "C"); //select & Copy
		
		act.click(password).keyDown(Keys.CONTROL).sendKeys("V"); //paste
		
		act.keyUp(Keys.CONTROL).build().perform();

	}

}
