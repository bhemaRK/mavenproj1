package ActionsClass;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsClass {

	static WebDriver driver;

	public static void main(String[] args) {
		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		driver = new ChromeDriver();

		// Implicitly wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the application url
		driver.get("https://www.amazon.in/");

		// maximize the screen
		driver.manage().window().maximize(); // method chaining

		// Click on Electronics using Actions class

		WebElement electronics_Menu = driver.findElement(By.xpath("//a[normalize-space()='Electronics']"));

		// Create an object of Actions class
		Actions act = new Actions(driver);

		act.moveToElement(electronics_Menu).click().perform();
		
		driver.quit();

	}

}
