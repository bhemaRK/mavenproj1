package ActionsClass;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragAndDrop {

	public static void main(String[] args) throws Exception {

		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// Implicitly wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the application url
		driver.get("https://demo.guru99.com/test/drag_drop.html");

		// maximize the screen
		driver.manage().window().maximize(); // method chaining

		// Capture the element from source location to drag
		WebElement source1 = driver.findElement(By.xpath("//a[normalize-space()='SALES']"));

		WebElement target1 = driver.findElement(By.id("loan"));

		// Drag And Drop
		Actions act = new Actions(driver);

		act.dragAndDrop(source1, target1).build().perform();
		
		Thread.sleep(5000);
		
		driver.quit();
	}

}
