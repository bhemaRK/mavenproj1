package pac1;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewDemoTest {

	@BeforeClass
	public void launch() {
		System.out.println("Launch the broswer");
	}

	@BeforeMethod
	public void login() {
		System.out.println("Login to the application");
	}
	
	@Test
	public void createCustomerTest() {
		System.out.println("Crerate Customer Test");
	}

	@Test
	public void modifyCustomerTest() {
		System.out.println("Modify Customer Test");
	}

	@AfterMethod
	public void logOut() {
		System.out.println("LogOut from the application");
	}

	@AfterClass
	public void closeBrowser() {
		System.out.println("Close the browser");
	}

}
