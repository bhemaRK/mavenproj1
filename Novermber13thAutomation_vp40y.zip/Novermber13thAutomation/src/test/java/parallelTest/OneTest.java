package parallelTest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class OneTest {
	@Test(groups = {"Regression Test"})
	public void webDriverAPITest() {

		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// hit the application url
		driver.get("https://www.facebook.com/");

		// maximize the screen
		driver.manage().window().maximize(); // method chaining

		// navigate to amazon webpage
		driver.navigate().to("https://amazon.in");

		// navigate back to facebook page
		driver.navigate().back();

		// validate if the user is on facebook page or not
		String currenturl = driver.getCurrentUrl();

		System.out.println("currenturl = " + currenturl);

		if (currenturl.contains("facebook")) {
			System.out.println("User is on Facebook Login Page");
		} else {
			System.out.println("User is still on Amazon Login Page");
		}

		// navigate forward to amazon web page
		driver.navigate().forward();

		// validate if the user is on Amazon.in
		String currentTitle = driver.getTitle();
		System.out.println("currentTitle = " + currentTitle);

		if (currentTitle.contains("Amazon.in")) {
			System.out.println("User has landed on Amazon web page");
		} else {
			System.out.println("User is still on facebook web page");
		}

		// refresh the browser
		driver.navigate().refresh();
		System.out.println("Browser has been refreshed");

		// delete the cookies
		driver.manage().deleteAllCookies();
		System.out.println("Deleted all the cookies");

		// get the entire page source
		// driver.getPageSource();

		// close the entire browser
		driver.quit();
	}

	@Test(groups = {"Regression Test"})
	public void webElementAPITest() throws Exception {
		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// Implicitly wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the application url
		driver.get("https://www.facebook.com/");

		// maximize the screen
		driver.manage().window().maximize(); // method chaining

		// Enter Email in the email edit box
		WebElement email = driver.findElement(By.xpath("//input[@placeholder='Email address or phone number']"));
		email.clear();
		email.sendKeys("rakeshinghraks@gmail.com");

		// enter password in the password component
		driver.findElement(By.id("pass")).sendKeys("Hakoomatata");

		// click on login button
		driver.findElement(By.name("login")).click();

		// capture error message
		WebElement errorMsg = driver.findElement(By.className("_9ay7"));

		// extract error message
		String textErrorMsg = errorMsg.getText();

		// verify that correct error message is displayed or not
		if (textErrorMsg.contains("email address you entered isn't connected")) {
			System.out.println("Actual error message is as per the requirement");
		} else {
			System.out.println("Actual error message is not as per the requirement");
		}

		// Explicitly wait
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text() = 'Log in to Facebook']")));

		// verify if the element - "Log in to Facebook" is Displayed or not
		WebElement LoginTextElement = driver.findElement(By.xpath("//div[text() = 'Log in to Facebook']"));

		boolean status = LoginTextElement.isDisplayed();

		System.out.println("Is Log in to Facebook displayed = " + status);

		// navigate back
		driver.navigate().back();
		System.out.println("User has been navigated back");

		// Check if the "Create new Account" button is enabled or not
		WebElement createNewAccount = driver.findElement(By.xpath("//a[contains(@data-testid,'registration')]"));

		boolean isItEnabled = createNewAccount.isEnabled();
		System.out.println("Is Create new Account button enabled = " + isItEnabled);

		if (createNewAccount.isEnabled())
			// if there is only 1 statement after if then no need to give body
			createNewAccount.click();

		// java wait statement
		Thread.sleep(1000);

		// check if the sign-up button is displayed to check that Pop-up has appeared
		WebElement submitButton = driver.findElement(By.name("websubmit"));

		if (submitButton.isDisplayed()) {
			// get the tagname for the element
			String tagName = submitButton.getTagName();
			System.out.println("tagName = " + tagName);

			// get the attribute value for "type" attribute
			String typeAttribute = submitButton.getAttribute("type");
			System.out.println("typeAttribute = " + typeAttribute);

			// get the font family details from CSS
			String fontFamily = submitButton.getCssValue("font-family");
			System.out.println("fontFamily = " + fontFamily);

			// get the background color
			String backgroundcolour = submitButton.getCssValue("background-color");
			System.out.println("backgroundcolour = " + backgroundcolour);
			
			driver.quit();


		}
	}

	@Test(groups = {"Smoke Test"})
	public void locatorsTest() throws Exception {
		// step 1: Set the property to launch the browser
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// Step 2: launch empty browser
		WebDriver driver = new ChromeDriver();

		// step 3: Hit facebook url
		driver.get("https://www.amazon.in/");

		// implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// maximize
		driver.manage().window().maximize();

		Thread.sleep(3000);
		
		// click on mobile
		WebElement mobiles = driver.findElement(By.linkText("Mobiles"));

		mobiles.click();

		Thread.sleep(3000);

		// Click on Customer Service
		driver.findElement(By.partialLinkText("Service")).click();

		// navigate to guru99 and click on the logo
		driver.navigate().to("https://www.guru99.com/");

		Thread.sleep(3000);

		driver.findElement(By.className("custom-logo")).click();
		
		driver.quit();

	}
}
