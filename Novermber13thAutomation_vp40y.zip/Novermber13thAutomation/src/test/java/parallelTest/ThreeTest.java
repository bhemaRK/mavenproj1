package parallelTest;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class ThreeTest {
	@Test(groups = {"Regression Test" , "Smoke Test"})
	public void WindowSwitchingTest() {

		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// Implicitly wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the application url
		driver.get("https://www.irctc.co.in/");

		// maximize the window
		driver.manage().window().maximize();

		// click on flights window
		driver.findElement(By.xpath("//a[contains(@aria-label,'Menu Flight')]")).click();

		// to get to know on which window I am
		String windowTitle = driver.getTitle();
		System.out.println("windowTitle = " + windowTitle);

		if (windowTitle.equalsIgnoreCase("IRCTC Next Generation eTicketing System")) {
			System.out.println("User is on Parent Window");
		}

		// since 2 windows are opened now, we need to capture the unique identifier for
		// the windows - window ID

		String currentWindow = driver.getWindowHandle(); // return the current window id. where selenium is currently
															// focusing
		System.out.println("currentWindow = " + currentWindow);

		// get all the window ids which are opened by selenium
		Set<String> set = driver.getWindowHandles();
		System.out.println(set);

		// Iterator methods to retrieve the data from set object
		Iterator<String> it = set.iterator();

		String parentWindow = it.next();
		System.out.println("parentWindow = " + parentWindow);

		// check if the next window id is available.
		boolean doWeHaveNextElement = it.hasNext();

		System.out.println("doWeHaveNextElement = " + doWeHaveNextElement); // true - if next value exists

		String FlightsWindow = it.next();

		// now switch the focus of selenium from parent window to Flights window
		driver.switchTo().window(FlightsWindow);

		String currentUrl = driver.getCurrentUrl();

		if (currentUrl.contains("air")) {
			System.out.println("User is on flights window");
			driver.close();
			// after closing the current window - selenium focus will be lost, because
			// selenium was focusing here
		}

		// Regain the focus
		driver.switchTo().window(parentWindow);

		// click on from edit box and provide details
		driver.findElement(By.xpath("//input[contains(@class,'ng-tns-c57-8 ui-inputtext ui-widget')]"))
				.sendKeys("Bangalore");
		
		driver.quit();

	}

	@Test(groups = {"Regression Test"})
	public void PopUpHandlingTest() throws Exception {
		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// Implicitly wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the application url
		driver.get("https://www.flipkart.com/");

		// maximize the window
		driver.manage().window().maximize();

		// Check if the popup is displayed

		WebElement popUpCross = driver.findElement(By.xpath("//span[text() = '✕']"));

		if (popUpCross.isDisplayed()) {
			popUpCross.click();
		}

		// perform the search activity
		WebElement search = driver.findElement(By.xpath("//input[@title='Search for Products, Brands and More']"));

		search.sendKeys("Precious Diamond");

		Thread.sleep(3000);

		// Hit enter
		Actions act = new Actions(driver);

		act.sendKeys(Keys.ENTER).perform();

		WebElement youtube = driver.findElement(By.xpath("//a[@href='https://www.youtube.com/flipkart']"));

		// act.scrollToElement(youtube);

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy (0,1250)");
		
		driver.quit();
	}

}
