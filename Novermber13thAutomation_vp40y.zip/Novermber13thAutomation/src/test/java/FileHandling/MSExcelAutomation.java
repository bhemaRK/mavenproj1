package FileHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class MSExcelAutomation {

	public static void main(String[] args) throws Exception {

		getExcelData();
		//setExcelData();
	}

	public static void getExcelData() throws Exception {

		// It stores the path of the Test Data file
		File filepath = new File("..\\Novermber13thAutomation\\TestData\\TestData.xlsx");

		// FileInputStream is meant for reading streams of data.
		FileInputStream fis = new FileInputStream(filepath);

		// Open Work book in a read mode.
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		// Get the control of sheet
		XSSFSheet sheet = workbook.getSheet("Sheet1");

		// get the control of the row
		XSSFRow row = sheet.getRow(1);

		// Get the data from desired cell of the current row
		String url = row.getCell(2).getStringCellValue();
		String username = row.getCell(3).getStringCellValue();
		String password = row.getCell(4).getStringCellValue();

		System.out.println("url = " + url);
		System.out.println("username = " + username);
		System.out.println("password = " + password);

	}

	public static void setExcelData() throws Exception {

		// It stores the path of the Test Data file
		File filepath = new File("..\\Novermber13thAutomation\\TestData\\TestData.xlsx");

		// FileInputStream is meant for reading streams of data.
		FileInputStream fis = new FileInputStream(filepath);

		// Open Work book in a read mode.
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		// Get the control of sheet
		XSSFSheet sheet = workbook.getSheet("Sheet1");

		// get the control of the row
		XSSFRow row = sheet.getRow(1);

		// create a cell at the end of the row or at 5th position
		XSSFCell cell = row.createCell(5);

		FileOutputStream fos = new FileOutputStream(filepath);

		cell.setCellValue("Contract CDR-11252");

		workbook.write(fos);

		workbook.close();
	}

}
