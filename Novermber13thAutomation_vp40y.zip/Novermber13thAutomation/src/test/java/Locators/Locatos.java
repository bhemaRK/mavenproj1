package Locators;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locatos {

	public static void main(String[] args) throws InterruptedException {

		// step 1: Set the property to launch the browser
		System.setProperty("webdriver.chrome.driver",
				"..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// Step 2: launch empty browser
		WebDriver driver = new ChromeDriver();

		// step 3: Hit facebook url
		driver.get("https://www.amazon.in/");
		
		// implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		// maximize
		driver.manage().window().maximize();
		
		//click on mobile
		WebElement mobiles = driver.findElement(By.linkText("Mobiles"));
		
		mobiles.click();
		
		Thread.sleep(3000);
		
		//Click on Customer Service
		driver.findElement(By.partialLinkText("Service")).click();
		
		//navigate to guru99 and click on the logo
		driver.navigate().to("https://www.guru99.com/sap-pp-tutorials.html");
		
		Thread.sleep(3000);
		
		driver.findElement(By.className("custom-logo")).click();
	}

}
