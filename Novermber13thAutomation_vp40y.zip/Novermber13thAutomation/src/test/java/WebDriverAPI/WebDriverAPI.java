package WebDriverAPI;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriverAPI {

	public static void main(String[] args) {

		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// hit the application url
		driver.get("https://www.facebook.com/");

		// maximize the screen
		driver.manage().window().maximize(); // method chaining

		// navigate to amazon webpage
		driver.navigate().to("https://amazon.in");

		// navigate back to facebook page
		driver.navigate().back();

		// validate if the user is on facebook page or not
		String currenturl = driver.getCurrentUrl();

		System.out.println("currenturl = " + currenturl);

		if (currenturl.contains("facebook")) {
			System.out.println("User is on Facebook Login Page");
		} else {
			System.out.println("User is still on Amazon Login Page");
		}

		// navigate forward to amazon web page
		driver.navigate().forward();

		// validate if the user is on Amazon.in
		String currentTitle = driver.getTitle();
		System.out.println("currentTitle = " + currentTitle);

		if (currentTitle.contains("Amazon.in")) {
			System.out.println("User has landed on Amazon web page");
		} else {
			System.out.println("User is still on facebook web page");
		}

		// refresh the browser
		driver.navigate().refresh();
		System.out.println("Browser has been refreshed");

		// delete the cookies
		driver.manage().deleteAllCookies();
		System.out.println("Deleted all the cookies");

		//get the entire page source
		//driver.getPageSource();
		
		// close the entire browser
		driver.quit();

	}

}
