package TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import Generic.Drivers;
import Generic.WebDriverCommonLib;
import PageObjects.Login;

public class FacebookLoginTest {

	public static WebDriver driver;
	static WebDriverCommonLib readyMethod = new WebDriverCommonLib();

	@Test
	public void positiveFacebookLoginTest() throws Exception {

		// Initialize the driver object from the test case
		driver = Drivers.getBrowser();

		// Create an Object of Login class so that we can access all the elements using
		// page-factory method

		Login login = PageFactory.initElements(driver, Login.class);
		login.logInToApplication();

		readyMethod.verifytext(driver, "//div[@class='_9ay7']",
				"The email address or mobile number you entered isn't connected to an account. Find your account and log in.");

	}
}
