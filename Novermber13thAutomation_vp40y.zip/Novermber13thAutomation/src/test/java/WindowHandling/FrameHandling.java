package WindowHandling;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FrameHandling {

	public static void main(String[] args) {

		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// Implicitly wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the application url
		driver.get("http://the-internet.herokuapp.com/iframe");

		// maximize the window
		driver.manage().window().maximize();

		// switch to iframe to perform operation
		driver.switchTo().frame("mce_0_ifr");

		WebElement body = driver.findElement(By.id("tinymce"));

		body.clear();
		body.sendKeys("Rakesh Yogi");

		// switch to parent Html document or default content
		driver.switchTo().defaultContent();

		// capture the text from the header
		WebElement headerText = driver.findElement(By.tagName("h3"));

		System.out.println("headerText = " + headerText.getText());
	}

}
