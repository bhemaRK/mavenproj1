package WindowHandling;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertsClass {

	static Alert alert;

	public static void main(String[] args) throws Exception {
		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// Implicitly wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the application url
		driver.get("http://the-internet.herokuapp.com/javascript_alerts");

		// maximize the window
		driver.manage().window().maximize();

		// capture Btn "Click for js Confirm"
		WebElement ClickForJSConfirm = driver.findElement(By.xpath("//button[text() = 'Click for JS Confirm']"));
		ClickForJSConfirm.click();

		// shift focus of selenium from HTML to javaScript Alerts
		alert = driver.switchTo().alert();

		Thread.sleep(5000);

		// Capture the message from the alert
		String currentAlertMessage = alert.getText();
		System.out.println("currentAlertMessage = " + currentAlertMessage);

		// accept the alert
		// alert.accept();
		alert.dismiss();

		WebElement result = driver.findElement(By.id("result"));

		System.out.println("result = " + result.getText());

		// capture btn "click on JS Prompt"
		driver.findElement(By.xpath("//button[@onclick='jsPrompt()']")).click();

		// shift focus of selenium from HTML to javaScript Alerts
		alert = driver.switchTo().alert();

		alert.sendKeys("Hakoonamatata");
		alert.accept();

		System.out.println("result = " + result.getText());

	}

}
