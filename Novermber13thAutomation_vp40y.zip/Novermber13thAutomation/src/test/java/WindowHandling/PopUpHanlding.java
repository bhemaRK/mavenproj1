package WindowHandling;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class PopUpHanlding {

	public static void main(String[] args) throws Exception {

		// Set the properties
		System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

		// launch the light browser
		WebDriver driver = new ChromeDriver();

		// Implicitly wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Hit the application url
		driver.get("https://www.flipkart.com/");

		// maximize the window
		driver.manage().window().maximize();

		// Check if the popup is displayed

		WebElement popUpCross = driver.findElement(By.xpath("//span[text() = '✕']"));

		if (popUpCross.isDisplayed()) {
			popUpCross.click();
		}

		// perform the search activity
		WebElement search = driver.findElement(By.xpath("//input[@title='Search for Products, Brands and More']"));

		search.sendKeys("Precious Diamond");

		Thread.sleep(3000);

		// Hit enter
		Actions act = new Actions(driver);

		act.sendKeys(Keys.ENTER).perform();

		WebElement youtube = driver.findElement(By.xpath("//a[@href='https://www.youtube.com/flipkart']"));

		// act.scrollToElement(youtube);

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy (0,1250)");

	}

}
