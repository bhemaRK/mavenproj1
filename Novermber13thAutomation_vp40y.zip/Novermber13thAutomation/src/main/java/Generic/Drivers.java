package Generic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

public class Drivers {

	public static WebDriver driver;

	public static WebDriver getBrowser() {

		if (Constants.browser.equalsIgnoreCase("chrome")) {

			// Set the properties
			System.setProperty("webdriver.chrome.driver", "..\\Novermber13thAutomation\\Drivers\\chromedriver.exe");

			// launch the light browser
			driver = new ChromeDriver();
			
			//Which Browser is invoked
			System.out.println("Which Browser is invoked = "+Constants.browser);

		} else if (Constants.browser.equalsIgnoreCase("firefox")) {

			// Set the properties
			System.setProperty("webdriver.firefox.driver", "..\\Novermber13thAutomation\\Drivers\\geckoDriver.exe");

			// launch the light browser
			driver = new FirefoxDriver();
			
			//Which Browser is invoked
			System.out.println("Which Browser is invoked = "+Constants.browser);
			

		} else if (Constants.browser.equalsIgnoreCase("safari")) {

			// Set the properties
			System.setProperty("webdriver.safari.driver", "..\\Novermber13thAutomation\\Drivers\\safariDriver.exe");

			// launch the light browser
			driver = new SafariDriver();
			
			//Which Browser is invoked
			System.out.println("Which Browser is invoked = "+Constants.browser);
		}

	return driver;
	
	}

}
