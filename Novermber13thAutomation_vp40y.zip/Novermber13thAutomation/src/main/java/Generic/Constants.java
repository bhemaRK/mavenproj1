package Generic;

public interface Constants {

	String browser = "cHrOmE";

	// for firefox we have hard coded the value
	// String driverPath = "..\\Novermber13thAutomation\\Drivers\\" +
	// Constants.browser.toLowerCase()+ "driver.exe";
	
	String appUrl = "https://facebook.com";

	String testDataSheetPath = "..\\Novermber13thAutomation\\TestData\\TestData.xlsx";
	
	int gloablWait = 20;
}
