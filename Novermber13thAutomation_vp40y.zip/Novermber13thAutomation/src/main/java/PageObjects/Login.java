package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import Generic.Constants;
import Generic.Drivers;
import Generic.MSExcelAutomation;
import Generic.WebDriverCommonLib;

public class Login {

	public static WebDriver driver = Drivers.driver;

	static WebDriverCommonLib readyMethod = new WebDriverCommonLib();

	@FindBy(id = "email")
	private WebElement email;

	@FindBy(name = "pass")
	private WebElement password;

	@FindBy(xpath = "//button[@type = 'submit']")
	private WebElement loginBtn;

	@FindBy(xpath = "//div[@class='_9ay7']")
	private WebElement errorMsg;

	public void logInToApplication() throws Exception {

		// hit the url
		driver.get(Constants.appUrl);

		// maximize the window
		readyMethod.maximize(driver);

		// enter credentials and hit the login button
		email.sendKeys(MSExcelAutomation.getExcelData("Sheet1", 1, 3));
		password.sendKeys(MSExcelAutomation.getExcelData("Sheet1", 1, 4));

		loginBtn.click();

	}

}
